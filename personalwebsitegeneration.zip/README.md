# Professional Website Template

A modern, responsive website template for corporate risk management and financial advisory services.

## Features

- Fully responsive design
- Smooth scroll animations
- Mobile-friendly navigation
- Contact forms with mailto functionality
- Accordion components
- SEO optimized

## GitHub Pages Deployment

1. **Fork or clone this repository**
2. **Go to your repository Settings**
3. **Navigate to Pages** (in the left sidebar)
4. **Under "Source", select the branch** (usually `main` or `master`)
5. **Select the root folder** `/` as the source
6. **Click Save**

Your site will be published at: `https://yourusername.github.io/repository-name/`

## Customization

Edit the following files to personalize your site:

- `index.html` - Update content, contact information, and services
- `styles.css` - Modify colors, fonts, and styling
- `script.js` - Adjust interactive features

## Contact Form

The contact forms use `mailto:` links. Update the email address in:
- Line 18 in `index.html` (floating email button)
- Line 13 in `index.html` (floating WhatsApp button)
- `script.js` lines with `mailto:khoohunkhiang@gmail.com`

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

Free to use for personal and commercial projects.
